#!/usr/bin/python

def lambda_handler(event, context):
    return "Success"
